/*ORIGINAL CREATOR: Luca Garofalo (Lucksi)
AUTHOR: Luca Garofalo (Lucksi)
Copyright (C) 2021-2023 Lucksi <lukege287@gmail.com>
License: GNU General Public License v3.0*/

function English(){
    alert("This tool has been made by Luca Garofalo (Lucksi) in Sicily a small Italian island Thank you for have downloaded my Tool :)");
}

function Italiano(){
    alert("Questo tool è stato creato da Luca Garofalo (Lucksi) in Sicilia Grazie per aver scaricato il mio tool :)");
}

function French(){
    alert("Cette tool A été créé par Luca Garofalo (Lucksi) en Sicilia a petité Italien ile Merci beacoup pour avoir télécharge mon Tool :)");
}