/*ORIGINAL CREATOR: Luca Garofalo (Lucksi)
AUTHOR: Luca Garofalo (Lucksi)
Copyright (C) 2022-2023 Lucksi <lukege287@gmail.com>
License: GNU General Public License v3.0*/

function OpenNav(){
    document.getElementById("Hidden").style.display="block";
    document.getElementById("New").style.display="none";
    document.getElementById("Open").style.display="none";
}
function OpenNav2(){
    document.getElementById("Hidden2").style.display="block";
    document.getElementById("New").style.display="none";
    document.getElementById("Open").style.display="none";
}
