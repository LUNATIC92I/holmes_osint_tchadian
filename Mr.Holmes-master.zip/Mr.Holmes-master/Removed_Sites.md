# REMOVED SITES
<br>

## YOUTUBE: https://www.youtube.com
    gives always positive response even if the user doesn't exist

<br>

## TELEGRAM: https://telegram.org
    gives always positive response even if the user doesn't exist

<br>


## Sparkpeople: https://www.sparkpeople.com
    this site has been close


<br>



## STRIPCHAT: https://stripchat.com
    gives always connection error

<br>

## REDDIT: https://reddit.com
     gives always positive response even if the user doesn't exist

<br>

## NEW-REDDIT: https://new.reddit.com
     gives always positive response even if the user doesn't exist

## LEETCODE: https://leetcode.com/
     gives always positive response even if the user doesn't exist

<br>

## RAIDFORUMS: https://raidforums.com
     gives always positive response even if the user doesn't exist

<br>

## SPOTIFY: https://open.spotify.com
      gives always positive response even if the user doesn't exist

<br>

## THESE WEBSITES ARE NOT AVAIBLE FOR NOW AND MAY COME BACK IN THE FUTURES
